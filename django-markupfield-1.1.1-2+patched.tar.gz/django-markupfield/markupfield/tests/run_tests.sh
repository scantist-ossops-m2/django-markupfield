django-admin.py test --settings=markupfield.tests.settings --pythonpath=../..
